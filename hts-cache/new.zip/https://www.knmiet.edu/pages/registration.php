
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Registration Form</title>
    <link rel="stylesheet" href="css/style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8"> 
</head>

<body>
    <div class="wrapper">
        <div class="container">
            <div class="hero-section">
                <img width=""src="js/logo.jpeg">
                <div class="col">
                    <h3 class="alumni-heading" style="font-weight:bold;"><u>Registration/Admission Form</u></h3>
                </div>
                <div style="margin-top:10px" class="col-md-6">
                    <p style="color:#2e3192;font-size:28px;font-weight:bold;margin-bottom: 0px;">Dr. K.N. Modi Institute of <br>Engineering & Technology</p>
                    <p class="fa fa-map-marker" style="font-size: 18px; line-height:30px;"> Address - Kapda Mill Opps-SBI main branch<br> Modinagar, UP - 201204 (India)</p>
                    <p class="fa fa-phone" style="font-size: 18px; line-height: 25px;">
                        P : +91 8859500790 <br><span class="fa fa-envelope" style="font-size: 18px;">
                            E :
                            admissions@knmiet.edu
                        </span>
                    </p>
                </div>
            </div>
            <!-- Second Section -->
            <form class="form-horizontal" method="post" action="">
                <div class="sub-heading">
                    <h4>Course</h4>
                </div>

                <div class="content-section">
                    <p class="desc">Kindly select the  course  you want to take admission at <b>Dr. K.N. Modi Institute of Engineering & Technology</b></p>
                    <div class="second-section">
                        <div class="mini-section">
                            <div class="column-section">
                                <label class="control-label" for="bt">Course: <span class="mandatory"
                                        style="color: #ff0000;">*</span></label>
                            </div>
                            <div class="column-section">
                                <select name="courseName" onChange="validateCource(this)" id="courseName" class="option-value" required="">
                                    <option value=''>--Select Course--</option>
                                    <option value='B.tech'>B.tech</option>
                                    <option value='BCA'>BCA</option>
                                    <option value='BBA'>BBA</option>

                                </select>
                            </div>
                        </div>
                        <div class="mini-section">
                            <div class="column-section">
                                <label class="control-label" for="cl">Branch: <span class="mandatory"
                                        style="color: #ff0000;">*</span></label>
                            </div>
                            <div class="column-section">
                                <select name="branchName" disabled  id="branchName" class="" >
                                    <option value=''>--Select Branch--</option>
                                    <option value='Computer Science & Engg.'>Computer Science & Engg.</option>
                                    <option value='Electronics & Communication Engg'>Electronics & Communication Engg.</option>
                                    <option value='Chemical Engg.'>Chemical Engg.</option>
                                    <option value='Information Technology'>Information Technology</option>
                                    <option value='Chemical Engg'>Chemical Engg.</option>
                                    <option value='Electrial Engg'>Electrial Engg.</option>
                                    <option value='Civil Engg'>Civil Engg.</option>
                                    <option value='Mechanical Engg.'>Mechanical Engg.</option>
                                </select>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Third Section -->
                <div class="content-section">
                    <div class="sub-heading">
                        <h4 class="text-left">Personal Details</h4>
                    </div>
                    <div class="second-section-2">
                        <div class="mini-section-2">
                            <div class="text-section">
                                <div>
                                    <label class="control-label" for="fln">Full Name: <span class="mandatory"
                                            style="color: #ff0000;">*</span></label>
                                </div>
                                <div>
                                    <input id="name" class="textbox text_upper form-control" name="name" required=""
                                        type="text" />
                                </div>
                            </div>
                            <div class="text-section">

                                <div class="col-sm-3">
                                    <label class="control-label" for="em">Email: <span
                                            style="color: #ff0000;">*</span></label>
                                </div>
                                <div class="col-sm-3">
                                    <input id="emailid" class="textbox form-control" name="emailid" required=""
                                        type="email" />
                                </div>
                            </div>
                        </div>

                        <div class="mini-section-2">
                            <div class="text-section">

                                <div class="col-sm-3">
                                    <label class="control-label" for="em">Father Name: <span
                                            style="color: #ff0000;">*</span></label>
                                </div>
                                <div class="col-sm-3">
                                    <input id="father" class="textbox form-control" name="father" required=""
                                        type="text" />
                                </div>
                            </div>
                                 
                            <div class="text-section">


                                <div class="col-sm-3">
                                    <label class="control-label" for="mob">Mobile No. :<span
                                            style="color: #ff0000;">*</span></label>
                                </div>
                                <div class="col-sm-3">
                                    <input id="contactNo" class="textbox text_upper form-control" name="contactNo"
                                        required="" type="text" 
                                        onKeyPress="validateNumber(this)" />
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

              

                <!-- ****** -->


                <!-- ******** -->
                <p align="center">
                    <input type="submit" value="Pay Now" name="submitForm"
                        style="background:#2e3192; color:#FFFFFF; padding:10px 20px; border:none; border-radius:3px; font-size:16px; cursor:pointer">
                </p>
                <div>&nbsp;</div>
                <div>&nbsp;</div>
        </div>
    </div>
    <script>

function validateCource(s){
    if(s.value =='B.tech'){
        document.getElementById('branchName').disabled   =false;
        document.getElementById('branchName').required   =true;
    
    }else{
        document.getElementById('branchName').disabled =true;
    }
}

function validateNumber(s){
  s.value=   s.value.replace(/[^0-9+\.-]/g, '');
}

    </script>
</body>

</html>