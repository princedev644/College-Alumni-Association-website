<!DOCTYPE html>
<html lang="zxx">
<meta http-equiv="content-type" content="" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="shortcut icon" href="https://cdn.techdost.com/wp-content/uploads/2018/06/techdost-favicon-100-100.png">
    <meta name="viewport" content="width=device-width" />
    <meta charSet="utf-8" />
    <title>KNMIET College - B.Tech, BCA, BBA - 360 Virtual Tours</title>
    <meta name="robots" content="index,follow" />
    <meta name="googlebot" content="index,follow" />
    <meta name="description" content="KN Modi Foundation, Modinagar - 360 Virtual Tours" />
    <meta name="keywords" content="KN Modi Foundation, Modinagar - 360 Virtual Tours">
    <meta property="og:url" content="index.php" />         
    <meta property="og:type" content="website" />
    <meta property="og:title" content="KN Modi Foundation, Modinagar - 360 Virtual Tours" />
    <meta property="og:description" content="KN Modi Foundation, Modinagar - 360 Virtual Tours" />
    <meta property="og:locale" content="en_IE" />
    <meta property="og:site_name" content="KN Modi Foundation, Modinagar - 360 Virtual Tours" />
    <meta name="next-head-count" content="12" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://www.logodost.com/cdn/kn-modi/_next/static/css/97b747778c679820fc8f.css?v1757413361" />
    <link rel="stylesheet" href="https://www.logodost.com/cdn/kn-modi/_next/static/css/font-awesome.css" />
    <link rel="stylesheet" href="https://www.logodost.com/cdn/kn-modi/_next/static/css/76e11c9cf417387a6fa9.css?v10:22:41am" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <link rel="stylesheet" href="https://www.logodost.com/cdn/kn-modi/carousel-file/css/owl.carousel.min.css">
    <link rel="stylesheet" href="https://www.logodost.com/cdn/kn-modi/carousel-file/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://www.logodost.com/cdn/kn-modi/_next/static/css/my.css?v=1757413361">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prettyPhoto/3.1.6/css/prettyPhoto.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style type="text/css">
        .border-shadow{
            border: 1px solid black;
            padding: 0px;
            box-shadow: 4px 6px 7px 0px #e1e1e1;
        }
         .td-desc{
            font-size:13px;
        }
        .pt-40{
            padding-top: 40px;
        }
        .mt-20{
            margin-top: 20px;
        }
        .black  a{
            color: black;
        }
        .black  a:hover{
            text-decoration: underline;
        }
        .set-new-popup.fade .modal-dialog{
            width: 70%;
            max-width: 70%;
        }
        .set-iframe-code{
            width: 100%;
            height: 490px;
        }
        .modal-header{
            background: #000;
            padding: 0 14px;
        }
        .modal-title {
            margin: 0;
            line-height: 1.42857143;
            color: #fff;
        }
        .modal-header .close {
            color: #fff;
            opacity: 1;
        }
        .modal-header .close {
            margin-top: -17px;
            font-size: 40px;
        }
        .modal-header .close {
            padding: 1rem 1rem;
            margin: -1rem -1rem -1rem auto;
        }
        ol.top-menu-td li a{
            color:blue;
        }
        @media only screen and (max-width: 520px) {
             .set-new-popup.fade .modal-dialog{
                width: 90%;
                max-width: 90%;
                left: 14px;
            }
            .set-iframe-code{
                width: 100%;
                height: 450px;
            }
            .navbar-dark .navbar-brand{
                width: 80%;
            }
            .navbar-toggler-icon{
                height: 2.0em;
            }
            .adani-nav .navbar .navbar-nav{
                float:left !important;
            }
        }
        @media only screen and (max-width: 767px){
            .navbar-area {
                height: 80px;
            }
            .ptb-100 {
                padding-top: 90px;
                padding-bottom: 60px;
            }


        }
    </style>
</head>
<body id="body">
    <div id="__next">
        <div class="navbar-area fixed">
            <div class="adani-nav">
                <div class="container">
                   <nav class="navbar navbar-expand-md navbar-dark">
                      <a style="padding: 0px;" class="navbar-brand text-black" href="/"><img src="https://www.knmiet.edu/images/logo.jpg" alt="" width="200px"></a>
                      <button class="navbar-toggler sh-button" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon">
                            <!--<i class="fa fa-bars" aria-hidden="true"></i>-->
                            <span class="td-bar"></span>
                            <span class="td-bar"></span>
                            <span class="td-bar"></span>
                        </span>
                      </button>
                      <div class="collapse navbar-collapse" id="collapsibleNavbar">
                        <ul class="navbar-nav" style="float: right;">
                          <li class="nav-item">
                            <a class="nav-link" href="/">Home </a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#names">Colleges</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="#hostel">Hostel / Campus Life</a>
                          </li>   
                        </ul>
                      </div>
                    </div> 
                    </nav>
                </div>
            </div>
        </div>      
<section id="names" class="ptb-100">
    <div class="container">
        <div class="section-title">
            <span class="sub-title" style="font-size: 20px;">Dr. K.N. Modi Institute of Engineering, Modinagar, Ghaziabad (UP)</span>
            <!--<h3>Dr. K.N. Modi University, Newai, Tonk (Rajasthan)</h3>-->
        </div>
        <!--<ol class="black top-menu-td">-->
        <!--    <li class="under"><a href="#miet">KNMIET College</a></li>-->
        <!--    <li><a href="#miper">KNMIPER College</a></li>-->
        <!--    <li><a href="#cmd">CMD College</a></li>-->
        <!--    <li><a href="#mec">KNMEC College</a></li>-->
        <!--    <li><a href="#bed">GDMIE College - B.Ed</a></li>-->
        <!--    <li><a href="#Pmkvy1">Skill Development (PMKVY)</a></li>-->
        <!--    <li><a href="#Global1">Dr. K.N. Modi Global School (Hapur Road, KN GD Campus)</a></li>-->
        <!--    <li><a href="#Global2">Dr. K.N. Modi Global School (Opp: SBI, Kapda Mill Campus)</a></li>-->
        <!--    <li><a href="#pretty">Pretty Penguins (Hapur Road, KN MEC Campus)</a></li>-->
        <!--    <li><a href="#hostel">Hostel/Campus Life</a></li>-->
        <!--    <li><a href="#university">Dr. KN Modi University, Newai, Tonk (Rajasthan)</a></li>-->
        <!--</ol>-->
        <div class="row mt--15">
            <div class="col-lg-3 col-md-3 pt-40" id="miet"></div>
            <div class="col-lg-6 col-md-6 pt-40" id="miet">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='KNMIET College' data-url="https://www.google.com/maps/embed?pb=!4v1628833370071!6m8!1m7!1sCAoSLEFGMVFpcFBnOFluSEc3LWVpTnhGLUh5dkhaWXBUMVUyZ3FMRWxocDIwRkxo!2m2!1d28.84765543009301!2d77.57968897837681!3f0.7247476370503421!4f16.883197677539385!5f0.7820865974627469">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/miet.png" alt="">
                        </a>
                    </div>
                    <p>KNMIET</p>
                    <p class="td-desc">B.Tech, BCA, BBA</p>
                </div>
            </div>
             <div class="col-lg-3 col-md-3 pt-40" id="miet"></div>

            <!--<div class="col-lg-4 col-md-6 pt-40" id="miper">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='KNMIPER College' data-url="https://www.google.com/maps/embed?pb=!4v1628832855575!6m8!1m7!1sCAoSLEFGMVFpcE4wZ1FvMnQ4cWdrYU9iamdVaXp0am1Rb0JMNkxmYVBrcnR5b0ct!2m2!1d28.845726!2d77.57991899999999!3f8.337829493799177!4f11.418651374915072!5f0.7820865974627469">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/miper.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>KNMIPER College</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="cmd">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='CMD College' data-url="https://www.google.com/maps/embed?pb=!4v1628832504080!6m8!1m7!1sCAoSLEFGMVFpcE5Td21UVmhNbHZDZVN6djBQTU1HdHpRRE9GNlQ1anpLakQyMU5U!2m2!1d28.837789!2d77.57894399999999!3f9.781006168301548!4f5.121658197390772!5f0.4000000000000002">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/cmd.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>CMD College</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="mec">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='KNMEC College' data-url="https://www.google.com/maps/embed?pb=!4v1628832688524!6m8!1m7!1sCAoSLEFGMVFpcFA3NzNxMm5tZTkwRS1XS0k5TlBfQWVQVG1wdTRrZF9hNjlIYVBw!2m2!1d28.8394765!2d77.5793707!3f1.052642483713612!4f3.3816510903020145!5f0.4000000000000002">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/mec.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>KNMEC College</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="bed">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='GDMIE College - B.Ed' data-url="https://www.google.com/maps/embed?pb=!4v1628789507955!6m8!1m7!1sCAoSLEFGMVFpcE9XOTNrVEdPYUJDRXRhUmxwVlExLXRLX3M4cFJNM2loWmxOcndZ!2m2!1d28.8401352647716!2d77.58546736945233!3f256.8762430385789!4f-2.0139636482661274!5f0.7820865974627469">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/bed.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>GDMIE College - B.Ed</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="pmkvy1">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='Skill Development (PMKVY)' data-url="https://gothru.co/PR0ODU5jZ?index=scene_0&hlookat=250&vlookat=6&fov=120">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/pmkvy1.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>Skill Development (PMKVY)</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="miet">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='Skill Development (PMKVY)' data-url="https://gothru.co/PR0ODU5jZ?index=scene_1&hlookat=250&vlookat=6&fov=120">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/pmkvy2.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>Skill Development (PMKVY)</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="Global1">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='Dr. K.N. Modi Global School (Hapur Road, KN GD Campus)' data-url="https://www.google.com/maps/embed?pb=!4v1628832427054!6m8!1m7!1sCAoSLEFGMVFpcFAwc1lDSnVXSkozaDh5czQ0b1R5NFVTWElpdlktZXlKN3AyR1Ax!2m2!1d28.840088!2d77.584918!3f195.70933378718163!4f2.389232676250529!5f0.4000000000000002">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/global1.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>Dr. K.N. Modi Global School<br/>(Hapur Road, KN GD Campus)</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="Global2">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='Dr. K.N. Modi Global School (Opp: SBI, Kapda Mill Campus)' data-url="https://gothru.co/PK6rWRnyH?index=scene_0&hlookat=356&vlookat=-5&fov=140">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/global2.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>Dr. K.N. Modi Global School<br/>(Opp: SBI, Kapda Mill Campus)</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="pretty">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='Pretty Penguins (Hapur Road, KN MEC Campus)' data-url="https://gothru.co/PySh8BsXn?index=scene_1&hlookat=320&vlookat=0&fov=140">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/pretty.png?sdfg" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>Pretty Penguins<br/>(Hapur Road, KN MEC Campus)</p>-->
            <!--    </div>-->
            <!--</div>-->

            <!--<div class="col-lg-4 col-md-6 pt-40" id="university">-->
            <!--    <div class="contenedor text-center border-shadow">-->
            <!--        <div class="container_foto ">-->
            <!--            <a class="open-360-kn" target="_blank" data-title='Dr. K.N. Modi University, Newai, Tonk (Rajasthan)' data-url="https://www.google.com/maps/embed?pb=!4v1628921249784!6m8!1m7!1sCAoSLEFGMVFpcE9Pa1JyR2lYQkFleFdqSU5iNWFkR0hFWkJpZE9iOW1VSVY4YVg0!2m2!1d26.39175321579109!2d75.91856556127254!3f272.05182014357547!4f2.2078546435617454!5f0.7820865974627469">-->
            <!--                <img src="https://www.techdost.com/wp-content/uploads/2021/08/knmu.png" alt="">-->
            <!--            </a>-->
            <!--        </div>-->
            <!--        <p>Dr. K.N. Modi University, Newai, Tonk (Rajasthan)</p>-->
            <!--    </div>-->
            <!--</div>-->

        </div>
        
        <br/><br/><br/>

        <div class="section-title" id="hostel">
            <span class="sub-title">The college life at times can be real memorable</span>
            <h3>Hostel / Campus Life</h3>
        </div>

        <div class="row mt--15">

            <div class="col-lg-4 col-md-6 pt-40" id="miet">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Mahendra Hostel' data-url="https://gothru.co/P3raQxueu?index=scene_2&hlookat=171&vlookat=-2&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/mahendra.png" alt="">
                        </a>
                    </div>
                    <p>Mahendra Hostel</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Jagriti Hostel' data-url="https://gothru.co/P3raQxueu?index=scene_3&hlookat=298&vlookat=13&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/jagriti.png" alt="">
                        </a>
                    </div>
                    <p>Jagriti Hostel</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Pool Hostel' data-url="https://gothru.co/P3raQxueu?index=scene_19&hlookat=77&vlookat=0&fov=123">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/pool.png" alt="">
                        </a>
                    </div>
                    <p>Pool Hostel</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='CMD Hostel' data-url="https://gothru.co/Pou4N784D?index=scene_13&hlookat=118&vlookat=5&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/cmd-hostel.png" alt="">
                        </a>
                    </div>
                    <p>CMD Hostel</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Gyan Niwas Hostel' data-url="https://gothru.co/Pq3IZpq05?index=scene_1&hlookat=189&vlookat=1&fov=116">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/gyan.png?dfd" alt="">
                        </a>
                    </div>
                    <p>Gyan Niwas Hostel</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Hostel Room' data-url="https://gothru.co/P3raQxueu?index=scene_11&hlookat=28&vlookat=9&fov=128">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/room.png?dfd" alt="">
                        </a>
                    </div>
                    <p>Hostel Room</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Auditorium 1' data-url="https://gothru.co/P3raQxueu?index=scene_13&hlookat=68&vlookat=-2&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/audi1.png" alt="">
                        </a>
                    </div>
                    <p>Auditorium 1</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Auditorium 2' data-url="https://gothru.co/Pq13Jfy4M?index=scene_5&hlookat=106&vlookat=7&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/audi2.png?sdsd" alt="">
                        </a>
                    </div>
                    <p>Auditorium 2</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Gym' data-url="https://gothru.co/P3raQxueu?index=scene_15&hlookat=52&vlookat=5&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/gym.png" alt="">
                        </a>
                    </div>
                    <p>Gym</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Swimming Pool' data-url="https://gothru.co/P3raQxueu?index=scene_8&hlookat=28&vlookat=2&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/swimming.png?sd" alt="">
                        </a>
                    </div>
                    <p>Swimming Pool</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Lawn Tenis Ground' data-url="https://gothru.co/P3raQxueu?index=scene_17&hlookat=127&vlookat=7&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/lawn.png?ssa" alt="">
                        </a>
                    </div>
                    <p>Lawn Tenis Ground</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Play Ground 1' data-url="https://gothru.co/Pq3IZpq05?index=scene_0&hlookat=40&vlookat=2&fov=120">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/playground1.png?asa" alt="">
                        </a>
                    </div>
                    <p>Play Ground 1</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Play Ground 2' data-url="https://gothru.co/Pq3IZpq05?index=scene_4&hlookat=222&vlookat=2&fov=116">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/playground2.png?assda" alt="">
                        </a>
                    </div>
                    <p>Play Ground 2</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Badminton Court' data-url="https://gothru.co/Pq3IZpq05?index=scene_2&hlookat=45&vlookat=0&fov=116">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/badminton.png?vcvc" alt="">
                        </a>
                    </div>
                    <p>Badminton Court</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Basket Ball Court' data-url="https://gothru.co/Pq3IZpq05?index=scene_5&hlookat=27&vlookat=14&fov=116">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/basket.png?vcvc" alt="">
                        </a>
                    </div>
                    <p>Basket Ball Court</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Canteen' data-url="https://gothru.co/Pq13Jfy4M?index=scene_3&hlookat=122&vlookat=3&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/canteen.png?vcvc" alt="">
                        </a>
                    </div>
                    <p>Canteen</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Cannon' data-url="https://gothru.co/Pq3IZpq05?index=scene_6&hlookat=276&vlookat=2&fov=120">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/cannon.png?vdfdcvc" alt="">
                        </a>
                    </div>
                    <p>Cannon</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 pt-40" id="">
                <div class="contenedor text-center border-shadow">
                    <div class="container_foto ">
                        <a class="open-360-kn" target="_blank" data-title='Temple' data-url="https://gothru.co/P3raQxueu?index=scene_7&hlookat=257&vlookat=6&fov=140">
                            <img src="https://www.techdost.com/wp-content/uploads/2021/08/temple.png" alt="">
                        </a>
                    </div>
                    <p>Temple</p>
                </div>
            </div>
    </div>
</section>
        
        <section class="footer-area" style="padding-top: 0px;">
            <div class="container">
                <div class="copyright-area">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-sm-6 col-md-6">
                            <p>Copyright @ 2021 <a href="https://knmodifoundation.com/" target="_blank">KN Modi Foundation</a>. All Rights Reserved </p>
                        </div>
                        <div class="col-lg-6 col-sm-6 col-md-6">
                            <ul>
                                <li>Designed by <a href="https://www.techdost.com/google-street-view-trusted-agency/" target="_blank">Google 360 Virtual Tour By TechDost</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<div class="modal fade set-new-popup" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-header">
        <!-- <div class="col-md-12 text-center">
                <h3 class="set-new-popup-title" style="color: white;"></h3>
            </div> -->
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <div class="modal-content">

        <iframe src="" class="set-iframe-code" width="350" height="350" loading="lazy"></iframe>
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 class="set-new-popup-title"></h3>
            </div>
        </div>
    </div>
  </div>
</div>

    <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>
    <script src="https://logodost.com/cdn/kn-modi/carousel-file/js/owl.carousel.min.js"></script>
    <script src="https://logodost.com/cdn/kn-modi/carousel-file/js/jquery.shubh.js"></script>
    
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/prettyPhoto/3.1.6/js/jquery.prettyPhoto.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(e){

        $('body').on('click','.open-360-kn',function(e){
            e.preventDefault();
            __show();
            setTimeout(__hide(), 3000);
            $('.set-iframe-code').attr('src',$(this).attr('data-url'));
            $('.set-new-popup-title').html($(this).attr('data-title'));
            $('.set-new-popup').modal('show');
        });
        function __show(){

        }
        function __hide(){

        }
    });
</script>

<script>
   $(document).ready(function(){
       $(window).scroll(function () {
           if ($(window).scrollTop() > 300) {
               $(".navbar-area").addClass("navbaraddcolor");

           } else {
              $(".navbar-area").removeClass("navbaraddcolor");
           }
       });
    });
   var owl = $('.owl-carouselkdjfhksdfhkj');
    $('.owl-carouselkdjfhksdfhkj').owlCarousel({
    items:3,
    loop:false,
    margin:10,
     responsive:{
        0:{
            items:1,
            nav:true
        },
        480:{
            items:2,
            nav:true,
            loop:false
        },      
        768:{
            items:2,
            nav:true,
            loop:false
        },
        1024:{
            items:3,
            nav:true,
            loop:false
        },
        1460:{
            items:3,
            nav:true,
            loop:false
        }
    }
});


 $(document).ready(function(){
  $(".burger-menu").click(function(){
    $('.sidebar-modal').addClass('active');
  });
  $(".sidebar-modal-close-btn").click(function(){
    $('.sidebar-modal').removeClass("active");
  });
  //  $(".sidebar-modal").click(function(){
  //   $('.sidebar-modal').removeClass("active");
  // });
});
</script>

<script type="text/javascript">
        $('.google360').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        320:{
            items:2,
            nav:true,
            loop:false
        },  
        600:{
            items:2,
            nav:false
        },
        1000:{
            items:5,
            nav:true,
            loop:false
        }
    }
});
    </script>


<script type="text/javascript">
     $(window).on('load',function(){
       setTimeout(function(){
            $('.sidebar-modal').addClass('active');
       }, 3000); 
     });
</script>

<script type="text/javascript">
    $(document).ready(function(){
        $(".ddd").prettyPhoto();
        $("a[rel^='prettyPhoto']").prettyPhoto({
            social_tools:false
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function(){
      $(".sh-button").click(function(){
        // $(".collapse").slideToggle("slow",3000);
        $('.collapse').toggle();
      });
    });
</script>

<script type="text/javascript">
    var $modalOverlay = $('#modalOverlay'); // Cache your selectors
    var $modalOverlaynew = $('#modalOverlaynew'); // Cache your selectors

    var $modal        = $('#modal');
    var $modalnew        = $('#modalnew');

    var $modalbussOpen        = $('.modal-buss');
    var $modalClose   = $('.modalClose');
    var $modalOpen    = $('.modalOpen');

$modalOpen.click(function(){
    $(".td-form-heading").html('Google360');
    $modalOverlay.stop().fadeTo(500,1);
});

$modalbussOpen.click(function(){   
    $(".td-form-heading").html('Lets Discuss ');
    $modalOverlaynew.stop().fadeTo(500,1);
});

$modalClose.click(function(){
  $modalOverlay.stop().fadeTo(500,0, function(){ $(this).hide(); });
  $modalOverlaynew.stop().fadeTo(500,0, function(){ $(this).hide(); });
});

$modal.click(function( e ) {
   e.stopPropagation(); // otherwise the click would bubble up to the overlay
});
$modalnew.click(function( e ) {
   e.stopPropagation(); // otherwise the click would bubble up to the overlay
});

$modalClose.click(function(){
  $modalOverlay.click(); 
});
</script>

</body>
</html>